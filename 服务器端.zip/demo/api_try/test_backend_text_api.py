import argparse
import requests

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="测试后端文本交互API")
    p.add_argument("--base-url", default="http://127.0.0.1:8000", help="后端地址")
    p.add_argument("--username", default="demo_user", help="测试用户名")
    p.add_argument("--password", default="demo_pass_123", help="测试密码")
    p.add_argument("-m", "--message", required=True, help="要测试提问的文本内容")
    p.add_argument("--prompt", type=int, default=1, help="提示词模板编号(1或2)")
    return p

def ensure_token(base_url: str, username: str, password: str) -> str:
    payload = {"username": username, "password": password}
    reg_resp = requests.post(f"{base_url}/auth/register", json=payload, timeout=5)
    
    if reg_resp.status_code in (200, 201):
        return reg_resp.json()["access_token"]
    
    login_resp = requests.post(f"{base_url}/auth/login", json=payload, timeout=5)
    if login_resp.status_code != 200:
        raise RuntimeError(f"登录失败: {login_resp.status_code} {login_resp.text}")
    return login_resp.json()["access_token"]

def main():
    args = build_parser().parse_args()
    try:
        print("正在获取鉴权 Token...")
        token = ensure_token(args.base_url, args.username, args.password)
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        payload = {"message": args.message, "prompt": args.prompt, "with_text": True, "with_audio": False}
        
        print(f"发送问题: {args.message}")
        resp = requests.post(f"{args.base_url}/chat/text", headers=headers, json=payload, timeout=30)
        
        if resp.status_code == 200:
            result = resp.json()
            print("\n---------- 模型回复 ----------")
            print(result.get("answer", result.get("assistant_text", "无文本返回")))
            print("------------------------------")
        else:
            print(f"请求失败 [{resp.status_code}]: {resp.text}")
    except Exception as e:
        print(f"运行出错: {e}")

if __name__ == "__main__":
    main()